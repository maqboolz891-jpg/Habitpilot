package com.studypilot.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class AlarmActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        setContent {
            var a by remember { mutableIntStateOf(Random.nextInt(7, 19)) }
            var b by remember { mutableIntStateOf(Random.nextInt(3, 12)) }
            var answer by remember { mutableStateOf("") }
            var error by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF6558D3))) {
                Column(Modifier.fillMaxSize().background(Color(0xFF22213A)).padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GOOD MORNING", color = Color(0xFFBDB8F6), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(20.dp))
                    Text("Time to get moving.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(30.dp))
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Solve to dismiss", color = Color(0xFF77758C))
                            Spacer(Modifier.height(12.dp))
                            Text("$a + $b = ?", color = Color(0xFF22213A), fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                            OutlinedTextField(value = answer, onValueChange = { answer = it.filter(Char::isDigit) }, label = { Text("Your answer") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            if (error) Text("Not quite. Try again.", color = Color(0xFFB3261E))
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = {
                                if (answer.toIntOrNull() == a + b) {
                                    getSystemService(android.app.NotificationManager::class.java).cancel(202)
                                    finish()
                                } else error = true
                            }, modifier = Modifier.fillMaxWidth()) { Text("Dismiss alarm") }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("One small win starts the day.", color = Color(0xFFD3D0E5), fontSize = 13.sp)
                }
            }
        }
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() { /* Keep challenge on screen until solved. */ }
}
