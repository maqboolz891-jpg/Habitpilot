package com.studypilot.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Ink = Color(0xFF22213A)
private val Purple = Color(0xFF6558D3)
private val Canvas = Color(0xFFF6F5FB)
private val Muted = Color(0xFF77758C)
private val subjects = listOf("Physics", "Chemistry", "Biology")

data class StudyEntry(val date: String, val subject: String, val minutes: Int, val topic: String)
data class Habit(val name: String, val done: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createAlarmChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 303)
        }
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Canvas)) { StudyPilotApp(this) } }
    }
}

private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun prefs(c: Context) = c.getSharedPreferences("studypilot", Context.MODE_PRIVATE)
private fun entries(c: Context): MutableList<StudyEntry> {
    val a = JSONArray(prefs(c).getString("entries", "[]"))
    return MutableList(a.length()) { i -> a.getJSONObject(i).let { StudyEntry(it.getString("date"), it.getString("subject"), it.getInt("minutes"), it.optString("topic")) } }
}
private fun saveEntries(c: Context, list: List<StudyEntry>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("date", it.date).put("subject", it.subject).put("minutes", it.minutes).put("topic", it.topic)) }
    prefs(c).edit().putString("entries", a.toString()).apply()
}
private fun habitNames(c: Context): List<String> = prefs(c).getString("habit_names", "NCERT reading,Revision,MCQs,Exercise,Sleep on time")!!.split("|")
private fun doneHabits(c: Context): MutableSet<String> = prefs(c).getStringSet("done_${today()}", emptySet())!!.toMutableSet()
private fun setHabit(c: Context, name: String, checked: Boolean) {
    val s = doneHabits(c); if (checked) s.add(name) else s.remove(name)
    prefs(c).edit().putStringSet("done_${today()}", s).apply()
}
private fun streak(c: Context): Int {
    val days = entries(c).filter { it.minutes > 0 }.map { it.date }.toSet()
    var d = Calendar.getInstance(); var count = 0
    while (days.contains(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d.time))) { count++; d.add(Calendar.DAY_OF_YEAR, -1) }
    return count
}
private fun createAlarmChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = c.getSystemService(android.app.NotificationManager::class.java)
        nm.createNotificationChannel(android.app.NotificationChannel("study_alarm", "Study alarms", android.app.NotificationManager.IMPORTANCE_HIGH).apply {
            description = "StudyPilot alarm reminders"; lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        })
    }
}

@Composable
private fun StudyPilotApp(c: MainActivity) {
    var refresh by remember { mutableIntStateOf(0) }
    var showLog by remember { mutableStateOf(false) }
    var showHabit by remember { mutableStateOf(false) }
    var alarmTime by remember { mutableStateOf(prefs(c).getString("alarm_time", "07:00") ?: "07:00") }
    val list = remember(refresh) { entries(c) }
    val todayEntries = list.filter { it.date == today() }
    val total = todayEntries.sumOf { it.minutes }
    val checked = remember(refresh) { doneHabits(c) }

    Column(Modifier.fillMaxSize().background(Canvas).padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("STUDYPILOT", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Your day, in focus.", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("✦", color = Purple, fontSize = 30.sp)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 26.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("TODAY'S PROGRESS", color = Color(0xFFBDB8F6), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("${total / 60}h ${total % 60}m", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(12.dp)); Text("studied today", color = Color(0xFFD3D0E5), modifier = Modifier.padding(bottom = 6.dp))
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatPill("🔥 ${streak(c)} day streak")
                            StatPill("${todayEntries.size} study sessions")
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { showLog = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Text("+ Log study") }
                    OutlinedButton(onClick = { showHabit = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) { Text("Edit habits") }
                }
            }
            item { SectionTitle("Study breakdown", "Today's subject time") }
            item {
                subjects.forEach { s ->
                    val mins = todayEntries.filter { it.subject == s }.sumOf { it.minutes }
                    Card(Modifier.fillMaxWidth().padding(bottom = 7.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(17.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(when(s) { "Physics" -> "⚡"; "Chemistry" -> "🧪"; else -> "🧬" }, fontSize = 22.sp)
                            Spacer(Modifier.width(12.dp)); Text(s, modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.SemiBold)
                            Text("${mins / 60}h ${mins % 60}m", color = Purple, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { SectionTitle("Daily habits", "${checked.size}/${habitNames(c).size} completed") }
            items(habitNames(c)) { name ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = checked.contains(name), onCheckedChange = { setHabit(c, name, it); refresh++ })
                        Text(name, color = Ink, modifier = Modifier.weight(1f))
                    }
                }
            }
            item { SectionTitle("Study alarm", "A reminder that asks you to wake up") }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(alarmTime, color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Alarm dismissal requires solving a short maths question.", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val cal = Calendar.getInstance()
                                TimePickerDialog(c, { _, h, m ->
                                    alarmTime = String.format(Locale.US, "%02d:%02d", h, m)
                                    prefs(c).edit().putString("alarm_time", alarmTime).apply()
                                    scheduleAlarm(c, h, m)
                                    refresh++
                                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
                            }) { Text("Set alarm") }
                            OutlinedButton(onClick = { cancelAlarm(c); refresh++ }) { Text("Cancel") }
                        }
                        Text("For reliable alarms, allow notifications and exact alarms in Android settings.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            item { SectionTitle("Recent sessions", "Your study history") }
            items(list.takeLast(8).reversed()) { e ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(e.subject, color = Ink, fontWeight = FontWeight.SemiBold); Text("${e.date} · ${e.topic}", color = Muted, fontSize = 12.sp) }
                        Text("${e.minutes} min", color = Purple, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    if (showLog) LogDialog(onDismiss = { showLog = false }, onSave = { subject, mins, topic ->
        val updated = entries(c); updated.add(StudyEntry(today(), subject, mins, topic)); saveEntries(c, updated); showLog = false; refresh++
    })
    if (showHabit) HabitDialog(c, onDismiss = { showHabit = false }, onSave = { names ->
        prefs(c).edit().putString("habit_names", names.joinToString("|")).apply(); showHabit = false; refresh++
    })
}

@Composable private fun StatPill(text: String) {
    Surface(color = Color(0xFF393653), shape = RoundedCornerShape(50)) { Text(text, Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Color.White, fontSize = 12.sp) }
}
@Composable private fun SectionTitle(title: String, sub: String) {
    Column(Modifier.padding(top = 7.dp, bottom = 2.dp)) { Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(sub, color = Muted, fontSize = 12.sp) }
}
@Composable private fun LogDialog(onDismiss: () -> Unit, onSave: (String, Int, String) -> Unit) {
    var subject by remember { mutableStateOf("Physics") }; var mins by remember { mutableStateOf("60") }; var topic by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Log a study session") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Subject")
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { subjects.forEach { s -> FilterChip(selected = subject == s, onClick = { subject = s }, label = { Text(s) }) } }
            OutlinedTextField(value = mins, onValueChange = { mins = it.filter(Char::isDigit).take(4) }, label = { Text("Minutes studied") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("Chapter / topic (optional)") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { val n = mins.toIntOrNull() ?: 0; if (n in 1..1440) onSave(subject, n, topic.ifBlank { "Study session" }) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
@Composable private fun HabitDialog(c: Context, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    var text by remember { mutableStateOf(habitNames(c).joinToString(", ")) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Your daily habits") }, text = {
        OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Separate habits with commas") })
    }, confirmButton = { TextButton(onClick = { onSave(text.split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct()) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

private fun scheduleAlarm(c: Context, hour: Int, minute: Int) {
    val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
    }
    val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
    val pi = android.app.PendingIntent.getBroadcast(c, 101, Intent(c, AlarmReceiver::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
}
private fun cancelAlarm(c: Context) {
    val pi = android.app.PendingIntent.getBroadcast(c, 101, Intent(c, AlarmReceiver::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
    (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
}
