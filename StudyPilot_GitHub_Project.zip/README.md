# StudyPilot — Android study & habit tracker

A native Android app for logging Physics/Chemistry/Biology study sessions, tracking daily habits and streaks, and setting a challenge-based study alarm.

## Features
- Daily study time totals and subject breakdown.
- Log a subject, minutes and chapter/topic.
- Editable daily habits with check-offs.
- Study streak based on days with logged study sessions.
- Recent study session history.
- One daily alarm; solving a simple addition challenge dismisses it.
- Data is stored locally on the phone using SharedPreferences.

## Build an APK with GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the outer `StudyPilot` folder).
3. Open **Actions** and select **Build StudyPilot APK**.
4. Tap **Run workflow** (or push to main/master).
5. Open the completed run and download the `StudyPilot-apk` artifact.
6. Extract the downloaded ZIP and install `app-debug.apk`.

## Android permissions and alarm behavior
- Allow notifications when Android asks.
- On Android 12+, allow **Alarms & reminders / Schedule exact alarms** for reliable timing.
- Full-screen alarm display depends on Android's notification and full-screen-intent settings and may be restricted by the phone manufacturer.
- The app schedules one alarm for the next occurrence of the selected time. Set it again after it rings if you want another day.

## Important limitations
- Study time is manually logged; this app does not monitor other apps or verify studying.
- The alarm challenge is a simple addition problem, not a security lock. A force-stop, reboot, battery restrictions, or device-specific alarm policies may affect delivery. The current starter does not restore alarms after reboot.
- This is a debug APK for personal testing, not a Play Store release.
